package util;

/**
 * global hadoop counter
 * @author pengfan
 *
 */
public enum MoreIterations {
	numberOfIterations
}
