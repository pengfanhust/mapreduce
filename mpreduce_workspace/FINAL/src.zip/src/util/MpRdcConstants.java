package util;

public class MpRdcConstants {
	public static final String ATTR_SEPRATOR = ",";
	public static final String FIELD_SEPRATOR = "\t";
	public static final int INFINITY = 99; 
	public static final int BLACK = -1;
	public static final int WHITE = -2;
	public static final int GRAY = -3;
}
